# ReRune CLI

### Build
```bash
go build -o bin/rerune ./cmd/rerune
```
```
