# ReRune CLI

## Install
The `rerune` binary is shipped alongside this README. Place it on your PATH so it is available in any terminal.

### macOS/Linux
Make it executable and move it to a directory on your PATH:

```bash
chmod +x rerune
sudo mv rerune /usr/local/bin/
```

If you prefer a user-local install, move it to `~/.local/bin` and ensure that directory is on your PATH:

```bash
mkdir -p ~/.local/bin
mv rerune ~/.local/bin/
export PATH="$HOME/.local/bin:$PATH"
```

### Windows
Move `rerune.exe` to a directory on your PATH (for example `%USERPROFILE%\bin`), then open a new terminal.

```powershell
New-Item -ItemType Directory -Force $env:USERPROFILE\bin
Move-Item .\rerune.exe $env:USERPROFILE\bin\
setx PATH "$env:USERPROFILE\bin;$env:PATH"
```

Verify the installation:

```bash
rerune -version
```

## Usage
Start the interactive CLI:

```bash
rerune
```

The CLI will guide you through:
- entering your API key
- selecting a project
- selecting a platform
- choosing the translations folder

### Controls
- `↑/↓` or `j/k` to move
- `Enter` to select or submit
- `q`, `esc`, or `ctrl+c` to quit or cancel
