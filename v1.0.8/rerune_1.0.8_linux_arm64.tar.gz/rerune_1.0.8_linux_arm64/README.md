# ReRune CLI

## Install

### Arch Linux (AUR)

After `rerune-bin` is published to AUR, install it with:

```bash
yay -S rerune-bin
```

### Prebuilt archive

The `rerune` binary is shipped alongside this README. Place it on your PATH so it is available in any terminal.

### macOS/Linux
Make it executable and move it to a directory on your PATH:

```bash
chmod +x rerune
sudo mv rerune /usr/local/bin/
```

If you prefer a user-local install, move it to `~/.local/bin` and ensure that directory is on your PATH:

```bash
mkdir -p ~/.local/bin
mv rerune ~/.local/bin/
export PATH="$HOME/.local/bin:$PATH"
```

### Windows
Move `rerune.exe` to a directory on your PATH (for example `%USERPROFILE%\bin`), then open a new terminal.

```powershell
New-Item -ItemType Directory -Force $env:USERPROFILE\bin
Move-Item .\rerune.exe $env:USERPROFILE\bin\
setx PATH "$env:USERPROFILE\bin;$env:PATH"
```

Verify the installation:

```bash
rerune version
```

## Update

On macOS and Linux, update the active installation with:

```bash
rerune update
```

ReRune delegates Homebrew installs to `brew`, AUR installs to `yay` or `paru`, and the default user-local install to the maintained installer. Other standalone binaries are replaced in place after the release archive and extracted executable checksums pass verification. ReRune does not request `sudo` for standalone updates.

On Windows, run the maintained PowerShell installer again:

```powershell
irm https://rerune.io/install.ps1 | iex
```

## Usage

Start the interactive CLI:

```bash
rerune
```

The CLI will guide you through:
- entering your API key
- selecting or creating a project
- selecting a platform
- choosing the translations folder

Configured users can also create projects, add languages, and create one-time OTA Publish IDs from the `Manage projects` menu.

### Commands

Print the complete command reference, including guidance for scripts and AI agents,
or ask for one command:

```bash
rerune help
rerune help project create
```

Pull or push translations for the configured project:

```bash
rerune pull
rerune push
```

Discover eligible organisations and available projects:

```bash
rerune organisation list
rerune project list
```

Add `--json` to either list command for machine-readable output.

Create a project:

```bash
rerune project create \
  --organisation 0123456789abcdef01234567 \
  --name Website \
  --language en=English \
  --language de=German
```

`--notes`, `--description`, and `--guidelines` are optional. The first repeated `--language` value becomes the main language. Add `--json` to receive the complete project response.

Add a language to the configured project:

```bash
rerune project language add --code de --name German
```

Use `--project <id>` to target another project. When the target is active, ReRune refreshes the language snapshot in `rerune.json` before reporting success.

Create a non-expiring or expiring OTA Publish ID:

```bash
rerune project ota-id create
rerune project ota-id create --expires-at 2026-12-31T23:59:59Z
```

The command prints the plaintext value once. It does not store the value in `rerune.json`.

### Controls
- `↑/↓` or `j/k` to move
- `Enter` to select or submit
- `esc` to go back in project-management flows
- `q` or `ctrl+c` to quit
- `ctrl+s` to continue from multiline project fields
- `c` to copy a newly created OTA Publish ID

## License

ReRune CLI is licensed under the [MIT License](LICENSE).
