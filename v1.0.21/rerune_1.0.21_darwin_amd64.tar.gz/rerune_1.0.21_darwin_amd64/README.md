# ReRune CLI

## Install

### Homebrew (macOS and Linux)

```bash
brew install basalbit/tap/rerune
```

### Arch Linux (AUR)

Every release publishes the `rerune-bin` package to the AUR. Install it with an AUR helper:

```bash
yay -S rerune-bin
```

Without a helper, build and install it with `makepkg`:

```bash
git clone https://aur.archlinux.org/rerune-bin.git && cd rerune-bin && makepkg -si
```

### Debian, Ubuntu, Linux Mint, Pop!_OS (APT)

The signed APT repository at `pkg.rerune.io` carries `rerune` for amd64 and arm64, starting with the first release that ships `.deb` packages. Each release is tested on Debian 12 and 13, Ubuntu 22.04, 24.04 and 26.04, and Linux Mint 22 (Debian 11 is best-effort) before it is published. Add the repository and install:

```sh
curl -fsSL https://pkg.rerune.io/rerune-archive-keyring.gpg | sudo tee /usr/share/keyrings/rerune-archive-keyring.gpg >/dev/null
sudo tee /etc/apt/sources.list.d/rerune.sources >/dev/null <<'EOF'
Types: deb
URIs: https://pkg.rerune.io/apt
Suites: stable
Components: main
Architectures: amd64 arm64
Signed-By: /usr/share/keyrings/rerune-archive-keyring.gpg
EOF
sudo apt update && sudo apt install rerune rerune-archive-keyring
```

Upgrade with a normal `sudo apt upgrade`, or only rerune with `sudo apt update && sudo apt install --only-upgrade rerune`. The first command stores the signing key at `/usr/share/keyrings/rerune-archive-keyring.gpg`, the file the `rerune-archive-keyring` package owns once it is installed, and the source trusts only that file. A future signing key therefore arrives through the same upgrade. The signing key fingerprint is `25A4 3D9B C619 2114 6E1D 6FCE 9CE4 DBD0 53BF 88CB`.

### Prebuilt archive

The `rerune` binary is shipped alongside this README. Place it on your PATH so it is available in any terminal.

### macOS/Linux
Make it executable and move it to a directory on your PATH:

```bash
chmod +x rerune
sudo mv rerune /usr/local/bin/
```

If you prefer a user-local install, move it to `~/.local/bin` and ensure that directory is on your PATH:

```bash
mkdir -p ~/.local/bin
mv rerune ~/.local/bin/
export PATH="$HOME/.local/bin:$PATH"
```

### Windows
Move `rerune.exe` to a directory on your PATH (for example `%USERPROFILE%\bin`), then open a new terminal.

```powershell
New-Item -ItemType Directory -Force $env:USERPROFILE\bin
Move-Item .\rerune.exe $env:USERPROFILE\bin\
setx PATH "$env:USERPROFILE\bin;$env:PATH"
```

Verify the installation:

```bash
rerune version
```

## Update

On macOS and Linux, update the active installation with:

```bash
rerune update
```

ReRune delegates Homebrew installs to `brew`, the `rerune-bin` pacman package to `yay` or `paru`, and the default user-local install to the maintained installer. ReRune never runs `sudo` or a system package manager itself. Instead it prints the command to run:

- `rerune-bin` without `yay` or `paru`: the `pacman` or `makepkg` command.
- The `rerune` package from the APT repository: `sudo apt update && sudo apt install --only-upgrade rerune`.
- A Nix profile install: `nix profile upgrade --all`. A Nix configuration that uses the `rerune` flake input: `nix flake update rerune`, then rebuild that configuration.

In these cases ReRune exits with status 2 when a newer version is available or the latest version could not be checked, and 0 when the installation is already current. Other standalone binaries are replaced in place after the release archive and extracted executable checksums pass verification. ReRune does not request `sudo` for standalone updates.

On Windows, run the maintained PowerShell installer again:

```powershell
irm https://rerune.io/install.ps1 | iex
```

## Usage

Start the interactive CLI:

```bash
rerune
```

The CLI will guide you through:
- entering your API key
- selecting or creating a project
- selecting a platform
- choosing the translations folder

Configured users can also create projects, add languages, and create one-time OTA Publish IDs from the `Manage projects` menu.

### Commands

Print the complete command reference, including guidance for scripts and AI agents,
or ask for one command:

```bash
rerune help
rerune help project create
```

Pull or push translations for the configured project:

```bash
rerune pull
rerune push
```

Both commands merge key by key against the last successful sync, which ReRune
records in `.rerune-sync.json` next to `rerune.json`. Push uploads only the keys
you changed locally and prints what it uploaded and what it took from the server.
When a key changed both locally and on the server, both commands stop and list
the conflicts; rerun with `rerune push --force` to keep your values or
`rerune pull --force` to take the server values. Commit `.rerune-sync.json`
whenever you commit `rerune.json`.

Discover eligible organisations and available projects:

```bash
rerune organisation list
rerune project list
```

Add `--json` to either list command for machine-readable output.

Create a project:

```bash
rerune project create \
  --organisation 0123456789abcdef01234567 \
  --name Website \
  --language en=English \
  --language de=German
```

`--notes`, `--description`, and `--guidelines` are optional. The first repeated `--language` value becomes the main language. Add `--json` to receive the complete project response.

Add a language to the configured project:

```bash
rerune project language add --code de --name German
```

Use `--project <id>` to target another project. When the target is active, ReRune refreshes the language snapshot in `rerune.json` before reporting success.

Create a non-expiring or expiring OTA Publish ID:

```bash
rerune project ota-id create
rerune project ota-id create --expires-at 2026-12-31T23:59:59Z
```

The command prints the plaintext value once. It does not store the value in `rerune.json`.

### Controls
- `↑/↓` or `j/k` to move
- `Enter` to select or submit
- `esc` to go back in project-management flows
- `q` or `ctrl+c` to quit
- `ctrl+s` to continue from multiline project fields
- `c` to copy a newly created OTA Publish ID

## License

ReRune CLI is licensed under the [MIT License](LICENSE).
